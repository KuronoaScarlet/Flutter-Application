package com.example.pardocarboignasi

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
